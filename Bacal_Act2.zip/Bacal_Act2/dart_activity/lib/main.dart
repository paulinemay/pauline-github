import 'dart:io' show stdin;

Future<void> main() async {
  double f1 = 45.75;
  double f2 = 43.18;
  double f3 = 37.12;
  double f4 = 48.03;

  print('TYPE OF FUEL: ');
  var fuel = stdin.readLineSync();

  if (fuel == 'L') {
    print('Leaded Fuel');

    print('TYPE OF PURCHASE');
    var pay = stdin.readLineSync();
    if (pay == 'Cash') {
      print('Input Amount: ');
      var amount = int.parse(stdin.readLineSync());
      var lit = amount / f1;
      print('$lit Liter of Leaded Gasoline');
    } else if (pay == 'Liter') {
      print('Input How Many Liters: ');
      var Lit = int.parse(stdin.readLineSync());
      var TA = Lit * f1;
      print('Total Amount: $TA');
      print('Input CASH :');
      var C = int.parse(stdin.readLineSync());
      var ch = C - TA;
      print('Change : $ch');
    } else {
      print('Invalid type of Purchase');
    }
  }

  if (fuel == 'U') {
    print('Uneaded Fuel');

    print('TYPE OF PURCHASE');
    var pay = stdin.readLineSync();
    if (pay == 'Cash') {
      print('Input Amount: ');
      var amount = int.parse(stdin.readLineSync());
      var lit = amount / f2;
      print('$lit Liter of Unleaded Gasoline');
    } else if (pay == 'Liter') {
      print('Input How Many Liters:  ');
      var Lit = int.parse(stdin.readLineSync());
      var TA = Lit * f2;
      print('Total Amount: $TA');
      print('Input CASH : ');
      var C = int.parse(stdin.readLineSync());
      var ch = C - TA;
      print('Change : $ch');
    } else {
      print('Invalid type of Purchase');
    }
  }

  if (fuel == 'D') {
    print('Diesel Fuel');

    print('TYPE OF PURCHASE');
    var pay = stdin.readLineSync();
    if (pay == 'Cash') {
      print('Input Amount: ');
      var amount = int.parse(stdin.readLineSync());
      var lit = amount / f3;
      print('$lit Liter of Diesel Fuel');
    } else if (pay == 'Liter') {
      print('Input How Many Liters:  ');
      var Lit = int.parse(stdin.readLineSync());
      var TA = Lit * f3;
      print('Total Amount: $TA');
      print('Input CASH : ');
      var C = int.parse(stdin.readLineSync());
      var ch = C - TA;
      print('Change : $ch');
    } else {
      print('Invalid type of Purchase');
    }
  }

  if (fuel == 'B') {
    print('Bio-Diesel Fuel');

    print('TYPE OF PURCHASE');
    var pay = stdin.readLineSync();
    if (pay == 'Cash') {
      print('Input Amount: ');
      var amount = int.parse(stdin.readLineSync());
      var lit = amount / f4;
      print('$lit Liter of Bio-Diesel Fuel');
    } else if (pay == 'Liter') {
      print('Input How Many Liters:  ');
      var Lit = int.parse(stdin.readLineSync());
      var TA = Lit * f4;
      print('Total Amount: $TA');
      print('Input CASH : ');
      var C = int.parse(stdin.readLineSync());
      var ch = C - TA;
      print('Change : $ch');
    } else {
      print('Invalid type of Purchase');
    }
  } else {
    print('Invalid Type of Fuel');
  }
}
